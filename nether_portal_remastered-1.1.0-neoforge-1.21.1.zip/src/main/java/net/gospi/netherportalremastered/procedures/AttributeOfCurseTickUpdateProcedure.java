package net.gospi.netherportalremastered.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.gospi.netherportalremastered.init.NetherPortalRemasteredModMobEffects;
import net.gospi.netherportalremastered.init.NetherPortalRemasteredModAttributes;

import javax.annotation.Nullable;

@EventBusSubscriber
public class AttributeOfCurseTickUpdateProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livingEntity0 && _livingEntity0.getAttributes().hasAttribute(NetherPortalRemasteredModAttributes.CURSE_OF_NETHER_ATTRIBUTE)
				? _livingEntity0.getAttribute(NetherPortalRemasteredModAttributes.CURSE_OF_NETHER_ATTRIBUTE).getBaseValue()
				: 0) == 1) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(NetherPortalRemasteredModMobEffects.CURSE_OF_NETHER, (int) Double.POSITIVE_INFINITY, 0, false, false));
		}
	}
}