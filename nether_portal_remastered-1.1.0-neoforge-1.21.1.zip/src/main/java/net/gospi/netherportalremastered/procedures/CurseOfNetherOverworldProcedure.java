package net.gospi.netherportalremastered.procedures;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;

import net.gospi.netherportalremastered.init.NetherPortalRemasteredModMobEffects;
import net.gospi.netherportalremastered.init.NetherPortalRemasteredModItems;
import net.gospi.netherportalremastered.init.NetherPortalRemasteredModAttributes;

import javax.annotation.Nullable;

@EventBusSubscriber
public class CurseOfNetherOverworldProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if ((entity.level().dimension()) == Level.OVERWORLD) {
			if (entity instanceof LivingEntity _livEnt3 && _livEnt3.hasEffect(NetherPortalRemasteredModMobEffects.CURSE_OF_NETHER)) {
				if (entity instanceof LivingEntity _livingEntity4 && _livingEntity4.getAttributes().hasAttribute(NetherPortalRemasteredModAttributes.CURSE_OF_NETHER_ATTRIBUTE))
					_livingEntity4.getAttribute(NetherPortalRemasteredModAttributes.CURSE_OF_NETHER_ATTRIBUTE).setBaseValue(0);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.DARKNESS);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.HUNGER);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.WEAKNESS);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(NetherPortalRemasteredModMobEffects.CURSE_OF_NETHER);
			}
		}
		if ((entity.level().dimension()) == Level.NETHER) {
			if (hasEntityInInventory(entity, new ItemStack(NetherPortalRemasteredModItems.PROTECTIVE_AMULET.get()))) {
				if (entity instanceof LivingEntity _livEnt14 && _livEnt14.hasEffect(NetherPortalRemasteredModMobEffects.CURSE_OF_NETHER)) {
					if (entity instanceof LivingEntity _livingEntity15 && _livingEntity15.getAttributes().hasAttribute(NetherPortalRemasteredModAttributes.CURSE_OF_NETHER_ATTRIBUTE))
						_livingEntity15.getAttribute(NetherPortalRemasteredModAttributes.CURSE_OF_NETHER_ATTRIBUTE).setBaseValue(0);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.DARKNESS);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.HUNGER);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.DIG_SLOWDOWN);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(MobEffects.WEAKNESS);
					if (entity instanceof LivingEntity _entity)
						_entity.removeEffect(NetherPortalRemasteredModMobEffects.CURSE_OF_NETHER);
				}
			}
		}
	}

	private static boolean hasEntityInInventory(Entity entity, ItemStack itemstack) {
		if (entity instanceof Player player)
			return player.getInventory().contains(stack -> !stack.isEmpty() && ItemStack.isSameItem(stack, itemstack));
		return false;
	}
}