/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.gospi.netherportalremastered.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.gospi.netherportalremastered.potion.CurseOfNetherMobEffect;
import net.gospi.netherportalremastered.NetherPortalRemasteredMod;

public class NetherPortalRemasteredModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, NetherPortalRemasteredMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> CURSE_OF_NETHER = REGISTRY.register("curse_of_nether", () -> new CurseOfNetherMobEffect());
}