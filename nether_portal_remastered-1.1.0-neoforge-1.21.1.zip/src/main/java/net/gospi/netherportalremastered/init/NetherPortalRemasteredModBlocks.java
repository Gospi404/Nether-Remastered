/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.gospi.netherportalremastered.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.gospi.netherportalremastered.block.ObsidianRuneWildBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneWayfinderBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneWardBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneVexBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneTideBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneSpireBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneSnoutBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneSilenceBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneShaperBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneSentryBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneRibBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneRaiserBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneHostBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneFlowBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneEyeBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneDuneBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneCoastBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneBoltBlock;
import net.gospi.netherportalremastered.block.ObsidianRuneBlock;
import net.gospi.netherportalremastered.NetherPortalRemasteredMod;

public class NetherPortalRemasteredModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(NetherPortalRemasteredMod.MODID);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_BOLT = REGISTRY.register("obsidian_rune_bolt", ObsidianRuneBoltBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_VEX = REGISTRY.register("obsidian_rune_vex", ObsidianRuneVexBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_FLOW = REGISTRY.register("obsidian_rune_flow", ObsidianRuneFlowBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_WILD = REGISTRY.register("obsidian_rune_wild", ObsidianRuneWildBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_DUNE = REGISTRY.register("obsidian_rune_dune", ObsidianRuneDuneBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_COAST = REGISTRY.register("obsidian_rune_coast", ObsidianRuneCoastBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_EYE = REGISTRY.register("obsidian_rune_eye", ObsidianRuneEyeBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_WAYFINDER = REGISTRY.register("obsidian_rune_wayfinder", ObsidianRuneWayfinderBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_RAISER = REGISTRY.register("obsidian_rune_raiser", ObsidianRuneRaiserBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_WARD = REGISTRY.register("obsidian_rune_ward", ObsidianRuneWardBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_TIDE = REGISTRY.register("obsidian_rune_tide", ObsidianRuneTideBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_HOST = REGISTRY.register("obsidian_rune_host", ObsidianRuneHostBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_SENTRY = REGISTRY.register("obsidian_rune_sentry", ObsidianRuneSentryBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_SHAPER = REGISTRY.register("obsidian_rune_shaper", ObsidianRuneShaperBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_SILENCE = REGISTRY.register("obsidian_rune_silence", ObsidianRuneSilenceBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_RIB = REGISTRY.register("obsidian_rune_rib", ObsidianRuneRibBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_SNOUT = REGISTRY.register("obsidian_rune_snout", ObsidianRuneSnoutBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE_SPIRE = REGISTRY.register("obsidian_rune_spire", ObsidianRuneSpireBlock::new);
	public static final DeferredBlock<Block> OBSIDIAN_RUNE = REGISTRY.register("obsidian_rune", ObsidianRuneBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}