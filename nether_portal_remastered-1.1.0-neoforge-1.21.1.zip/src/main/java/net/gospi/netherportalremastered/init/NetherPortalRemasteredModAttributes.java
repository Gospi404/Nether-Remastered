/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.gospi.netherportalremastered.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.EntityAttributeModificationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.EntityType;
import net.minecraft.core.registries.BuiltInRegistries;

import net.gospi.netherportalremastered.NetherPortalRemasteredMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class NetherPortalRemasteredModAttributes {
	public static final DeferredRegister<Attribute> REGISTRY = DeferredRegister.create(BuiltInRegistries.ATTRIBUTE, NetherPortalRemasteredMod.MODID);
	public static final DeferredHolder<Attribute, Attribute> CURSE_OF_NETHER_ATTRIBUTE = REGISTRY.register("curse_of_nether_attribute",
			() -> new RangedAttribute("attribute.nether_portal_remastered.curse_of_nether_attribute", 0, 0, 1).setSyncable(true).setSentiment(Attribute.Sentiment.NEGATIVE));

	@SubscribeEvent
	public static void addAttributes(EntityAttributeModificationEvent event) {
		event.add(EntityType.PLAYER, CURSE_OF_NETHER_ATTRIBUTE);
	}
}