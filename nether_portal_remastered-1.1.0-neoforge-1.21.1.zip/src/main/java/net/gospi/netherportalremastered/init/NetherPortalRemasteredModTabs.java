/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.gospi.netherportalremastered.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.gospi.netherportalremastered.NetherPortalRemasteredMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class NetherPortalRemasteredModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, NetherPortalRemasteredMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> NETHER_REMASTERED = REGISTRY.register("nether_remastered", () -> CreativeModeTab.builder().title(Component.translatable("item_group.nether_portal_remastered.nether_remastered"))
			.icon(() -> new ItemStack(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_BOLT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_BOLT.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_VEX.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_FLOW.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WILD.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_DUNE.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_COAST.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_EYE.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WAYFINDER.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_RAISER.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WARD.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_TIDE.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_HOST.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SENTRY.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SHAPER.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SILENCE.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_RIB.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SNOUT.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SPIRE.get().asItem());
				tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE.get().asItem());
				tabData.accept(NetherPortalRemasteredModItems.PROTECTIVE_AMULET.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_BOLT.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_VEX.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_FLOW.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WILD.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_DUNE.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_COAST.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_EYE.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WAYFINDER.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_RAISER.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WARD.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_TIDE.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_HOST.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SENTRY.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SHAPER.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SILENCE.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_RIB.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SNOUT.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SPIRE.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_BOLT.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_VEX.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_FLOW.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WILD.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_DUNE.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_COAST.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_EYE.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WAYFINDER.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_RAISER.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WARD.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_TIDE.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_HOST.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SENTRY.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SHAPER.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SILENCE.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_RIB.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SNOUT.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SPIRE.get().asItem());
			tabData.accept(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(NetherPortalRemasteredModItems.PROTECTIVE_AMULET.get());
		}
	}
}