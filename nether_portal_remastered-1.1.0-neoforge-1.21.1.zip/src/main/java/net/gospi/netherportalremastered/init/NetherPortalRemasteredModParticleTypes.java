/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.gospi.netherportalremastered.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.gospi.netherportalremastered.NetherPortalRemasteredMod;

public class NetherPortalRemasteredModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(Registries.PARTICLE_TYPE, NetherPortalRemasteredMod.MODID);
	public static final DeferredHolder<ParticleType<?>, SimpleParticleType> CURSE_OF_NETHER_PARTICLE = REGISTRY.register("curse_of_nether_particle", () -> new SimpleParticleType(false));
}