/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.gospi.netherportalremastered.init;

import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.gospi.netherportalremastered.client.particle.CurseOfNetherParticleParticle;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class NetherPortalRemasteredModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(NetherPortalRemasteredModParticleTypes.CURSE_OF_NETHER_PARTICLE.get(), CurseOfNetherParticleParticle::provider);
	}
}