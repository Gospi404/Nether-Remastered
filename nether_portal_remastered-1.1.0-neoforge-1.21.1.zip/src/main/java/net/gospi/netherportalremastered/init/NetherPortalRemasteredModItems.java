/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.gospi.netherportalremastered.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.gospi.netherportalremastered.procedures.ProtectiveAmuletNetherActiveProcedure;
import net.gospi.netherportalremastered.item.ProtectiveAmuletItem;
import net.gospi.netherportalremastered.NetherPortalRemasteredMod;

public class NetherPortalRemasteredModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(NetherPortalRemasteredMod.MODID);
	public static final DeferredItem<Item> OBSIDIAN_RUNE_BOLT = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_BOLT, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_VEX = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_VEX, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_FLOW = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_FLOW, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_WILD = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WILD, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_DUNE = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_DUNE, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_COAST = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_COAST, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_EYE = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_EYE, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_WAYFINDER = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WAYFINDER, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_RAISER = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_RAISER, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_WARD = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_WARD, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_TIDE = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_TIDE, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_HOST = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_HOST, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_SENTRY = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SENTRY, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_SHAPER = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SHAPER, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_SILENCE = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SILENCE, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_RIB = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_RIB, new Item.Properties().rarity(Rarity.RARE).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_SNOUT = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SNOUT, new Item.Properties().rarity(Rarity.RARE).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE_SPIRE = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE_SPIRE, new Item.Properties().rarity(Rarity.EPIC).fireResistant());
	public static final DeferredItem<Item> OBSIDIAN_RUNE = block(NetherPortalRemasteredModBlocks.OBSIDIAN_RUNE, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> PROTECTIVE_AMULET = REGISTRY.register("protective_amulet", ProtectiveAmuletItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ItemsClientSideHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public static void clientLoad(FMLClientSetupEvent event) {
			event.enqueueWork(() -> {
				ItemProperties.register(PROTECTIVE_AMULET.get(), ResourceLocation.parse("nether_portal_remastered:protective_amulet_nether_active"),
						(itemStackToRender, clientWorld, entity, itemEntityId) -> (float) ProtectiveAmuletNetherActiveProcedure.execute(itemStackToRender));
			});
		}
	}
}