package net.gospi.netherportalremastered.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleOptions;

import net.gospi.netherportalremastered.procedures.CurseOfNetherKazhdyiTikVoVriemiaEffiektaProcedure;
import net.gospi.netherportalremastered.init.NetherPortalRemasteredModParticleTypes;

public class CurseOfNetherMobEffect extends MobEffect {
	public CurseOfNetherMobEffect() {
		super(MobEffectCategory.HARMFUL, -9363014);
		this.withSoundOnAdded(BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("item.ominous_bottle.dispose")));
	}

	@Override
	public ParticleOptions createParticleOptions(MobEffectInstance mobEffectInstance) {
		return (SimpleParticleType) (NetherPortalRemasteredModParticleTypes.CURSE_OF_NETHER_PARTICLE.get());
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public boolean applyEffectTick(LivingEntity entity, int amplifier) {
		CurseOfNetherKazhdyiTikVoVriemiaEffiektaProcedure.execute(entity);
		return super.applyEffectTick(entity, amplifier);
	}
}