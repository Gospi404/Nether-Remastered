package net.gospi.netherportalremastered.portal;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.gospi.netherportalremastered.init.NetherPortalRemasteredModBlocks;

import java.util.*;

public class PortalChecker {
	private static final TagKey<Block> OBSIDIAN_RUNE_TAG = TagKey.create(
			BuiltInRegistries.BLOCK.key(),
			ResourceLocation.fromNamespaceAndPath("nether_portal_remastered", "obsidian_rune")
	);

	/**
	 * Проверяет портал на наличие рун и возвращает силу защиты
	 * @param level уровень, на котором находится портал
	 * @param portalPos позиция портала (любой блок обсидиана/руны в портале)
	 * @return сила защиты портала (0 = нет защиты, -1 = бесконечная защита)
	 */
	public static int checkPortalProtection(Level level, BlockPos portalPos) {
		if (level.isClientSide()) {
			return 0;
		}

		// Используем упрощенный подход: проверяем все блоки обсидиана/руны в радиусе от позиции портала
		// Ищем рамку портала вручную
		Set<BlockPos> portalFrameBlocks = new HashSet<>();
		BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();
		
		// Проверяем блоки в радиусе 5 блоков от позиции портала
		// Ищем прямоугольную рамку из обсидиана или рун
		for (int x = -5; x <= 5; x++) {
			for (int y = -5; y <= 5; y++) {
				for (int z = -5; z <= 5; z++) {
					mutablePos.set(portalPos.getX() + x, portalPos.getY() + y, portalPos.getZ() + z);
					BlockState state = level.getBlockState(mutablePos);
					
					// Проверяем, является ли это блоком обсидиана или руной
					if (state.is(Blocks.OBSIDIAN) || isObsidianRune(state) || 
						state.is(Blocks.CRYING_OBSIDIAN)) {
						// Проверяем, является ли это частью рамки портала
						// Рамка портала обычно имеет размеры минимум 4x5 блоков
						if (isPortalFrameBlock(level, mutablePos)) {
							portalFrameBlocks.add(mutablePos.immutable());
						}
					}
				}
			}
		}

		// Подсчитываем силу рун
		boolean hasEndRune = false;
		Set<ResourceLocation> uniqueOverworldRunes = new HashSet<>();
		int netherRuneCount = 0;

		for (BlockPos pos : portalFrameBlocks) {
			BlockState state = level.getBlockState(pos);
			if (isObsidianRune(state)) {
				ResourceLocation blockId = BuiltInRegistries.BLOCK.getKey(state.getBlock());
				String blockName = blockId.getPath();
				
				// Руны из ада: rib, snout
				if (blockName.contains("rib") || blockName.contains("snout")) {
					netherRuneCount++;
				}
				// Руна из города края: spire
				else if (blockName.contains("spire")) {
					hasEndRune = true;
				}

				// Обычные руны из верхнего мира (все остальные)
				else {
					uniqueOverworldRunes.add(blockId);
				}
			}
		}

		// Новые требования:
		// 1. 10 разных рун из верхнего мира ИЛИ
		// 2. 5 рун из нижнего мира ИЛИ
		// 3. 1 руна из энда
		
		// Проверяем условие 1: 10 разных рун из верхнего мира
		if (uniqueOverworldRunes.size() >= 10) {
			return uniqueOverworldRunes.size();
		}
		
		// Проверяем условие 2: 5 рун из нижнего мира
		if (netherRuneCount >= 5) {
			return netherRuneCount;
		}
		
		// Проверяем условие 3: 1 руна из энда
		if (hasEndRune) {
			return -1; // Защита достаточна (возвращаем -1 для обозначения полной защиты)
		}

		return 0;
	}

	/**
	 * Проверяет, является ли блок руной обсидиана
	 */
	public static boolean isObsidianRune(BlockState state) {
		Block block = state.getBlock();
		ResourceLocation blockId = BuiltInRegistries.BLOCK.getKey(block);
		return blockId.getNamespace().equals("nether_portal_remastered") && 
			   blockId.getPath().startsWith("obsidian_rune");
	}

	/**
	 * Проверяет, является ли блок частью рамки портала
	 */
	private static boolean isPortalFrameBlock(Level level, BlockPos pos) {
		BlockState state = level.getBlockState(pos);
		if (!state.is(Blocks.OBSIDIAN) && !isObsidianRune(state) && !state.is(Blocks.CRYING_OBSIDIAN)) {
			return false;
		}
		
		// Проверяем соседние блоки - рамка портала должна быть рядом с воздухом или порталом
		int airCount = 0;
		for (net.minecraft.core.Direction dir : net.minecraft.core.Direction.values()) {
			BlockPos neighborPos = pos.relative(dir);
			BlockState neighborState = level.getBlockState(neighborPos);
			if (neighborState.isAir() || neighborState.is(Blocks.NETHER_PORTAL)) {
				airCount++;
			}
		}
		
		// Блок рамки портала должен быть рядом хотя бы с одним блоком воздуха/портала
		return airCount > 0;
	}

	/**
	 * Находит позицию портала в верхнем мире, соответствующую порталу в Незере
	 */
	public static BlockPos findOverworldPortal(ServerLevel netherLevel, BlockPos netherPos) {
		// Координаты в верхнем мире = координаты в Незере * 8
		BlockPos overworldPos = new BlockPos(
			netherPos.getX() * 8,
			netherPos.getY(),
			netherPos.getZ() * 8
		);

		ServerLevel overworldLevel = netherLevel.getServer().getLevel(Level.OVERWORLD);
		if (overworldLevel == null) {
			return null;
		}

		// Ищем ближайший блок обсидиана или руны в верхнем мире
		for (int range = 0; range < 128; range++) {
			for (int y = -64; y < 320; y++) {
				for (int x = -range; x <= range; x++) {
					for (int z = -range; z <= range; z++) {
						if (Math.abs(x) != range && Math.abs(z) != range) {
							continue;
						}
						BlockPos checkPos = overworldPos.offset(x, y, z);
						BlockState state = overworldLevel.getBlockState(checkPos);
						if (state.is(Blocks.OBSIDIAN) || isObsidianRune(state) || state.is(Blocks.CRYING_OBSIDIAN)) {
							// Проверяем, является ли это частью портала
							if (isPortalFrameBlock(overworldLevel, checkPos)) {
								return checkPos;
							}
						}
					}
				}
			}
		}

		return null;
	}
}

