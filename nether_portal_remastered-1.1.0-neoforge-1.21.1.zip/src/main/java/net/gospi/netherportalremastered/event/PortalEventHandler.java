package net.gospi.netherportalremastered.event;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityTravelToDimensionEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.NetherPortalBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.core.Direction;
import net.gospi.netherportalremastered.init.NetherPortalRemasteredModMobEffects;
import net.gospi.netherportalremastered.portal.PortalChecker;
import javax.annotation.Nullable;
import java.util.Optional;

public class PortalEventHandler {
    
    @SubscribeEvent
    public static void onEntityTravelToDimension(EntityTravelToDimensionEvent event) {
        Entity entity = event.getEntity();
        ResourceKey<Level> destination = event.getDimension();
        ResourceKey<Level> source = entity.level().dimension();
        
        // Проверяем, что это телепортация в Незер из верхнего мира
        // Переход из ада в верхний мир не требует рун и не накладывает проклятие
        if (destination == Level.NETHER && source == Level.OVERWORLD && entity instanceof LivingEntity livingEntity) {
            if (entity.level().isClientSide()) {
                return;
            }

            // Получаем позицию портала в верхнем мире
            BlockPos portalPos = findPortalPosition(entity);
            
            if (portalPos != null && entity.level() instanceof ServerLevel serverLevel) {
                // Проверяем защиту портала
                int protection = PortalChecker.checkPortalProtection(serverLevel, portalPos);
                
                // Если защита недостаточна, накладываем проклятие
                // protection == -1 означает полную защиту (1 руна из энда)
                // protection >= 10 означает защиту 10 рунами верхнего мира
                // protection >= 5 означает защиту 5 рунами нижнего мира
                if (protection == 0) {
                    // Накладываем проклятие на игрока и всех живых существ в радиусе
                    applyCurse(livingEntity);
                    
                    // Также накладываем на всех живых существ в радиусе 5 блоков
                    serverLevel.getEntitiesOfClass(LivingEntity.class, 
                        livingEntity.getBoundingBox().inflate(5.0), 
                        (e) -> e != livingEntity).forEach(PortalEventHandler::applyCurse);
                }
            } else {
                // Если не удалось найти портал, все равно накладываем проклятие
                // (это означает, что портал не защищен рунами)
                applyCurse(livingEntity);
            }
        }
        // Переход из ада в верхний мир не требует проверки и не накладывает проклятие
    }

    /**
     * Находит позицию портала, из которого телепортируется сущность
     */
    private static BlockPos findPortalPosition(Entity entity) {
        BlockPos entityPos = entity.blockPosition();
        Level level = entity.level();
        
        // Сначала ищем сам блок портала
        for (int x = -5; x <= 5; x++) {
            for (int y = -3; y <= 3; y++) {
                for (int z = -5; z <= 5; z++) {
                    BlockPos checkPos = entityPos.offset(x, y, z);
                    var state = level.getBlockState(checkPos);
                    if (state.is(Blocks.NETHER_PORTAL)) {
                        // Нашли портал, теперь ищем рамку
                        return findPortalFrameFromPortal(level, checkPos);
                    }
                }
            }
        }
        
        // Если портал не найден, ищем рамку из обсидиана или рун
        for (int x = -10; x <= 10; x++) {
            for (int y = -5; y <= 5; y++) {
                for (int z = -10; z <= 10; z++) {
                    BlockPos checkPos = entityPos.offset(x, y, z);
                    var state = level.getBlockState(checkPos);
                    if (state.is(Blocks.OBSIDIAN) || 
                        state.is(Blocks.CRYING_OBSIDIAN) ||
                        PortalChecker.isObsidianRune(state)) {
                        return checkPos;
                    }
                }
            }
        }
        
        return null;
    }
    
    /**
     * Находит рамку портала, начиная с блока портала
     */
    private static BlockPos findPortalFrameFromPortal(Level level, BlockPos portalPos) {
        // Ищем ближайший блок рамки (обсидиан или руна) рядом с порталом
        for (net.minecraft.core.Direction dir : net.minecraft.core.Direction.values()) {
            BlockPos checkPos = portalPos.relative(dir);
            BlockState state = level.getBlockState(checkPos);
            if (state.is(Blocks.OBSIDIAN) || 
                state.is(Blocks.CRYING_OBSIDIAN) ||
                PortalChecker.isObsidianRune(state)) {
                return checkPos;
            }
        }
        return portalPos;
    }

    /**
     * Накладывает проклятие на сущность
     */
    private static void applyCurse(LivingEntity entity) {
        // Накладываем проклятие с максимальной длительностью
        MobEffectInstance curse = new MobEffectInstance(
            NetherPortalRemasteredModMobEffects.CURSE_OF_NETHER, // Исправлено: убрали .get()
            Integer.MAX_VALUE, // Бесконечная длительность
            0,
            false, // Не показывать частицы
            true,  // Показывать иконку
            false  // Не лечится молоком
        );
        
        // Накладываем проклятие
        entity.addEffect(curse);
        
        // Также накладываем дополнительные эффекты
        entity.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, Integer.MAX_VALUE, 2, false, false, false));
        entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, Integer.MAX_VALUE, 0, false, false, false));
        entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, Integer.MAX_VALUE, 1, false, false, false));
        entity.addEffect(new MobEffectInstance(MobEffects.HUNGER, Integer.MAX_VALUE, 1, false, false, false));
    }

    /**
     * Обработчик события размещения блока - проверяет, нужно ли создать портал из рун
     */
    @SubscribeEvent
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
            return;
        }
        
        BlockPos pos = event.getPos();
        BlockState state = event.getPlacedBlock();
        
        // Проверяем, является ли размещенный блок руной или обсидианом
        if (PortalChecker.isObsidianRune(state) || 
            state.is(Blocks.OBSIDIAN) || 
            state.is(Blocks.CRYING_OBSIDIAN)) {
            
            // Планируем проверку портала через небольшой тик, чтобы рамка успела сформироваться
            net.gospi.netherportalremastered.NetherPortalRemasteredMod.queueServerWork(3, () -> {
                checkAndCreatePortal(serverLevel, pos);
            });
        }
    }
    
    /**
     * Обработчик события обновления блока - проверяет, нужно ли создать портал
     */
    @SubscribeEvent
    public static void onNeighborNotify(BlockEvent.NeighborNotifyEvent event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
            return;
        }
        
        BlockPos pos = event.getPos();
        BlockState state = event.getState();
        
        // Проверяем, является ли блок руной или обсидианом
        if (PortalChecker.isObsidianRune(state) || 
            state.is(Blocks.OBSIDIAN) || 
            state.is(Blocks.CRYING_OBSIDIAN)) {
            
            // Планируем проверку портала
            net.gospi.netherportalremastered.NetherPortalRemasteredMod.queueServerWork(2, () -> {
                checkAndCreatePortal(serverLevel, pos);
            });
        }
    }
    
    /**
     * Проверяет, можно ли создать портал из рун, и создает его, если возможно
     * Использует логику, аналогичную TestPortalShape
     */
    private static void checkAndCreatePortal(ServerLevel level, BlockPos pos) {
        // Проверяем оба возможных направления (X и Z)
        Optional<NetherPortalShape> optional = findEmptyPortalShape(level, pos, Direction.Axis.X);
        if (optional.isPresent()) {
            optional.get().createPortalBlocks();
            return;
        }
        
        optional = findEmptyPortalShape(level, pos, Direction.Axis.Z);
        if (optional.isPresent()) {
            optional.get().createPortalBlocks();
        }
    }
    
    /**
     * Ищет пустую форму портала (без блоков портала внутри)
     */
    private static Optional<NetherPortalShape> findEmptyPortalShape(LevelAccessor level, BlockPos pos, Direction.Axis axis) {
        return findPortalShape(level, pos, shape -> shape.isValid() && shape.numPortalBlocks == 0, axis);
    }
    
    /**
     * Ищет форму портала с заданным предикатом
     */
    private static Optional<NetherPortalShape> findPortalShape(LevelAccessor level, BlockPos pos, java.util.function.Predicate<NetherPortalShape> predicate, Direction.Axis axis) {
        Optional<NetherPortalShape> optional = Optional.of(new NetherPortalShape(level, pos, axis)).filter(predicate);
        if (optional.isPresent()) {
            return optional;
        } else {
            Direction.Axis otherAxis = axis == Direction.Axis.X ? Direction.Axis.Z : Direction.Axis.X;
            return Optional.of(new NetherPortalShape(level, pos, otherAxis)).filter(predicate);
        }
    }
    
    /**
     * Класс для определения формы портала из рун (аналогично TestPortalShape)
     */
    private static class NetherPortalShape {
        private static final int MIN_WIDTH = 4;
        private static final int MAX_WIDTH = 21;
        private static final int MIN_HEIGHT = 5;
        private static final int MAX_HEIGHT = 21;
        private static final BlockBehaviour.StatePredicate FRAME = (state, level, pos) -> 
            isValidFrameBlock(state);
        
        private final LevelAccessor level;
        private final Direction.Axis axis;
        private final Direction rightDir;
        private int numPortalBlocks;
        @Nullable
        private BlockPos bottomLeft;
        private int height;
        private final int width;
        
        public NetherPortalShape(LevelAccessor level, BlockPos pos, Direction.Axis axis) {
            this.level = level;
            this.axis = axis;
            this.rightDir = axis == Direction.Axis.X ? Direction.WEST : Direction.SOUTH;
            this.bottomLeft = this.calculateBottomLeft(pos);
            if (this.bottomLeft == null) {
                this.bottomLeft = pos;
                this.width = 1;
                this.height = 1;
            } else {
                this.width = this.calculateWidth();
                if (this.width > 0) {
                    this.height = this.calculateHeight();
                } else {
                    this.height = 0;
                }
            }
        }
        
        @Nullable
        private BlockPos calculateBottomLeft(BlockPos pos) {
            int minY = Math.max(this.level.getMinBuildHeight(), pos.getY() - 21);
            while (pos.getY() > minY && isEmpty(this.level.getBlockState(pos.below()))) {
                pos = pos.below();
            }
            Direction direction = this.rightDir.getOpposite();
            int distance = this.getDistanceUntilEdgeAboveFrame(pos, direction) - 1;
            return distance < 0 ? null : pos.relative(direction, distance);
        }
        
        private int calculateWidth() {
            int distance = this.getDistanceUntilEdgeAboveFrame(this.bottomLeft, this.rightDir);
            return distance >= MIN_WIDTH && distance <= MAX_WIDTH ? distance : 0;
        }
        
        private int getDistanceUntilEdgeAboveFrame(BlockPos pos, Direction direction) {
            BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();
            for (int i = 0; i <= MAX_WIDTH; i++) {
                mutablePos.set(pos).move(direction, i);
                BlockState state = this.level.getBlockState(mutablePos);
                if (!isEmpty(state)) {
                    if (FRAME.test(state, this.level, mutablePos)) {
                        return i;
                    }
                    break;
                }
                BlockPos.MutableBlockPos belowPos = new BlockPos.MutableBlockPos(mutablePos.getX(), mutablePos.getY(), mutablePos.getZ());
                belowPos.move(Direction.DOWN);
                BlockState belowState = this.level.getBlockState(belowPos);
                if (!FRAME.test(belowState, this.level, belowPos)) {
                    break;
                }
            }
            return 0;
        }
        
        private int calculateHeight() {
            BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();
            int distance = this.getDistanceUntilTop(mutablePos);
            return distance >= MIN_HEIGHT && distance <= MAX_HEIGHT && this.hasTopFrame(mutablePos, distance) ? distance : 0;
        }
        
        private boolean hasTopFrame(BlockPos.MutableBlockPos mutablePos, int height) {
            for (int i = 0; i < this.width; i++) {
                mutablePos.set(this.bottomLeft).move(Direction.UP, height).move(this.rightDir, i);
                if (!FRAME.test(this.level.getBlockState(mutablePos), this.level, mutablePos)) {
                    return false;
                }
            }
            return true;
        }
        
        private int getDistanceUntilTop(BlockPos.MutableBlockPos mutablePos) {
            for (int i = 0; i < MAX_HEIGHT; i++) {
                // Проверяем левую сторону
                mutablePos.set(this.bottomLeft).move(Direction.UP, i).move(this.rightDir, -1);
                if (!FRAME.test(this.level.getBlockState(mutablePos), this.level, mutablePos)) {
                    return i;
                }
                // Проверяем правую сторону
                mutablePos.set(this.bottomLeft).move(Direction.UP, i).move(this.rightDir, this.width);
                if (!FRAME.test(this.level.getBlockState(mutablePos), this.level, mutablePos)) {
                    return i;
                }
                // Проверяем внутреннюю область
                for (int j = 0; j < this.width; j++) {
                    mutablePos.set(this.bottomLeft).move(Direction.UP, i).move(this.rightDir, j);
                    BlockState state = this.level.getBlockState(mutablePos);
                    if (!isEmpty(state)) {
                        return i;
                    }
                    if (state.is(Blocks.NETHER_PORTAL)) {
                        this.numPortalBlocks++;
                    }
                }
            }
            return MAX_HEIGHT;
        }
        
        private static boolean isEmpty(BlockState state) {
            return state.isAir() || state.is(Blocks.NETHER_PORTAL);
        }
        
        public boolean isValid() {
            return this.bottomLeft != null && this.width >= MIN_WIDTH && this.width <= MAX_WIDTH && 
                   this.height >= MIN_HEIGHT && this.height <= MAX_HEIGHT;
        }
        
        public void createPortalBlocks() {
            BlockState portalState = Blocks.NETHER_PORTAL.defaultBlockState()
                .setValue(NetherPortalBlock.AXIS, this.axis);
            BlockPos.betweenClosed(
                this.bottomLeft, 
                this.bottomLeft.relative(Direction.UP, this.height - 1).relative(this.rightDir, this.width - 1)
            ).forEach(pos -> this.level.setBlock(pos, portalState, 18));
        }
    }
    
    /**
     * Проверяет, является ли блок валидным блоком рамки портала
     */
    private static boolean isValidFrameBlock(BlockState state) {
        return state.is(Blocks.OBSIDIAN) || 
               state.is(Blocks.CRYING_OBSIDIAN) ||
               PortalChecker.isObsidianRune(state);
    }
    
    /**
     * Инициализирует обработчик событий
     */
    public static void init() {
        NeoForge.EVENT_BUS.register(PortalEventHandler.class);
    }
}
