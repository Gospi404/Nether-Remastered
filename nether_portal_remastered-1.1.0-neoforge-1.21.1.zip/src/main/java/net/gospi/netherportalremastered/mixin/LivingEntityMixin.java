package net.gospi.netherportalremastered.mixin;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.gospi.netherportalremastered.init.NetherPortalRemasteredModMobEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    @Unique
    private MobEffectInstance savedCurse = null;
    
    /**
     * Предотвращает снятие проклятия незера через removeEffect
     */
    @Inject(method = "removeEffect", at = @At("HEAD"), cancellable = true)
    private void preventCurseRemoval(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity entity = (LivingEntity)(Object)this;
        
        // Если пытаются снять проклятие незера, блокируем это (кроме случаев, когда эффект истекает естественным образом)
        if (effect.is(NetherPortalRemasteredModMobEffects.CURSE_OF_NETHER)) {
            MobEffectInstance instance = entity.getEffect(effect);
            // Блокируем удаление, если эффект еще активен
            if (instance != null && instance.getDuration() > 100) {
                cir.setReturnValue(false);
                cir.cancel();
            }
        }
    }
    
    /**
     * Предотвращает снятие проклятия незера через curePotionEffects (молоко)
     */
    @Inject(method = "curePotionEffects", at = @At("HEAD"))
    private void saveCurseBeforeMilk(net.minecraft.world.item.ItemStack itemStack, CallbackInfo ci) {
        LivingEntity entity = (LivingEntity)(Object)this;
        
        // Сохраняем проклятие перед удалением всех эффектов
        MobEffectInstance curse = entity.getEffect(NetherPortalRemasteredModMobEffects.CURSE_OF_NETHER);
        if (curse != null && curse.getDuration() > 100) {
            // Сохраняем копию проклятия
            savedCurse = new MobEffectInstance(
                curse.getEffect(),
                curse.getDuration(),
                curse.getAmplifier(),
                curse.isAmbient(),
                curse.isVisible(),
                false // Не лечится молоком
            );
        } else {
            savedCurse = null;
        }
    }
    
    @Inject(method = "curePotionEffects", at = @At("RETURN"))
    private void restoreCurseAfterMilk(net.minecraft.world.item.ItemStack itemStack, CallbackInfo ci) {
        LivingEntity entity = (LivingEntity)(Object)this;
        
        // Восстанавливаем проклятие, если оно было удалено молоком
        if (!entity.level().isClientSide() && savedCurse != null) {
            // Проверяем, что проклятие действительно было удалено
            if (entity.getEffect(NetherPortalRemasteredModMobEffects.CURSE_OF_NETHER) == null) {
                // Восстанавливаем сохраненное проклятие
                entity.addEffect(savedCurse);
            }
            savedCurse = null;
        }
    }
}